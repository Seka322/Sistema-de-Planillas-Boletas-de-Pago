<?php
class Boletas_pago_model extends CI_Model
{
    var $table = 'boletas_pago';

	public function get_all_boletas()
	{
		$this->db->select('boletas_pago.*, trabajadores.dni')
		->from($this->table)
		->join('trabajadores', 'boletas_pago.id_trabajador = trabajadores.id');
		$result = $this->db->get();
		return $result;
	}


	public function count_all()
    {
		$query = $this->get_all_boletas();
        return $query->num_rows();
    }

    public function boleta_data_by_id($id)
    {
        $this->db->from($this->table);
        $this->db->where('id', $id);
        $query = $this->db->get();
        return $query;
    }

    public function boleta_exists($data)
    {
        $id_trabajador = $data['id_trabajador'];
        $exists = false;
        $query = $this->db->query("SELECT * FROM $this->table WHERE id_trabajador = '$id_trabajador'");
        $rows = $query->num_rows();
        if ($rows > 0)
        {
            $exists = true;
        }
        return $exists;
    }

	public function duplicate_trabajador($data)
    {
        $id_trabajador = $data['id_trabajador'];
        $error = '';
        $query = $this->db->query("SELECT * FROM $this->table WHERE id_trabajador = '$id_trabajador'");
        $rows = $query->num_rows();
        if ($rows > 0)
        {
            $error = 'Ya existe un registro con el Trabajador: '. $id_trabajador;
        }
        return $error;
    }

    public function save($data)
    {
        $this->db->insert('boletas_pago', array(
            'id_trabajador' => $data['id_trabajador'],
            'fecha' => $data['fecha'],
            'horas_trabajadas' => $data['horas_trabajadas'],
            'monto_total' => $data['monto_total']
		));
    }

    public function delete_by_id($id_boleta)
    {
        $this->db->where('id', $id_boleta);
		$this->db->delete($this->table);
    }
}
